/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashing;

import java.util.Arrays;

/**
 *
 * @author Laksh
 */
public class Hashing implements IHash {
    private final Pairs[] arr;
    private final int maxSize;
    private int length;



    public static void main(String[] args) {
        Hashing h = new Hashing(5);
        h.add(1, "String");
        h.add(2, "String");
        h.add(3, "String");
        h.add(4, "String");
        h.add(5, "String");
        System.out.printf(h.toString());

    }

    public Hashing(int maxSize){
        this.maxSize = maxSize;
        arr = new Pairs[maxSize];
        length = 0;
    }
    
    public String[] asArray() {
        String[] elements = new String[maxSize];
        for (int i = 0; i < maxSize; i++){
            if (arr[i] != null){
                elements[i] = arr[i].getValue();
            }else{
                elements[i] = null;
            }
        }
        return elements;
    }    

    @Override
    public void add(int Key, String Value) {

        if (length == maxSize) {
            throw new UnsupportedOperationException();
        }
        if (contains(Key)){
            throw new IllegalArgumentException();
        }
        Pairs pair = new Pairs(Key, Value);

        arr[getHash(Key, null)] = pair;

        length++;
    }

    @Override
    public String item(int Key) {
        return arr[getHash(Key, String.valueOf(Key))].getValue();
    }

    @Override
    public void delete(int Key) {
        arr[getHash(Key, String.valueOf(Key))] = null;

        length--;
    }

    @Override
    public boolean contains(int Key) {
        try{
            arr[getHash(Key, String.valueOf(Key))].getKey();
            return true;
        }catch (IllegalArgumentException e){
            return false;
        }
    }

    @Override
    public int length() {
        return length;
    }

    @Override
    public boolean isEmpty() {
        return length == 0;
    }

    private int getHash(int key, String CollisionCheck){
        int hash = -1;

        for (int i = key % maxSize; i < (key % maxSize) + maxSize; i++){
            int x = i % maxSize;

            if (arr[x] == null){
                 if (CollisionCheck == null){
                     hash = x;
                     break;
                 }
            }else if (CollisionCheck != null){
                if (CollisionCheck.equals(String.valueOf(arr[x].getKey()))){
                    hash = x;
                    break;
                }
            }
        }
        if (hash == -1){
            throw new IllegalArgumentException();
        }
        return hash;
    }

    @Override
    public String toString() {
        StringBuilder s = new StringBuilder("{");
        for (int i = 0; i < maxSize; i++){
            Pairs x = arr[i];
            if (x == null){
                s.append("null:null" + (i != maxSize ? ", " : ""));
                continue;
            }
            s.append(x.getKey() + ":" + x.getValue() + (i != maxSize - 1 ? ", " : ""));
        }
        s.append("}");
        return s.toString();
    }
}
