package Laksh.LinkedList;

public class LinkedList {

    private Node head, tail;
    private int maxSize, size;

    public LinkedList(int maxSize){
        this.maxSize = maxSize;
        size = 0;
    }

    public boolean isFull(){
        return size == maxSize;
    }
    public boolean isEmpty() { return size == 0;}

    public void add(Node n, int index){
        if (isFull()){
            throw new ArrayIndexOutOfBoundsException("Linked List is Full");
        }
        size++;
        if (head == null){
            n.setIndex(0);
            head = n;
            tail = n;
            return;
        }

        tail.next = n;
        n.setIndex(n.getIndex() + 1);
        tail = n;

    }

    public Node remove(int index){ //TODO fix this disabled shit
        if (isEmpty()){
            throw new ArrayIndexOutOfBoundsException("Linked list is empty");
        }

        Node n = head;
        Node temp = n;
        for (int i = 0; i < index; i++){
            n = n.next;
            if (i + 1 == index){
                temp = n.next;
                n.next = n.next.next;
                n.next = null;
            }

        }

        return temp;

    }




}
