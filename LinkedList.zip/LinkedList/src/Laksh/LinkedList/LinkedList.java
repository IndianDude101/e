package Laksh.LinkedList;

public class LinkedList {
    private Node head, tail;
    private int maxSize, size;

    public LinkedList(int maxSize){
        this.maxSize = maxSize;
        size = 0;
    }

    public boolean isFull(){
        return size == maxSize;
    }

    public void add(Node n){
        if (isFull()){
            throw new ArrayIndexOutOfBoundsException("Linked List is Full");
        }
        size++;
        if (head == null){
            n.setIndex(0);
            head = n;
            tail = n;
            return;
        }

        tail.next = n;
        n.setIndex(n.getIndex() + 1);
        tail = n;

    }

    public Node remove(int index){
        for (int i = 0; i < index; )
    }


}
