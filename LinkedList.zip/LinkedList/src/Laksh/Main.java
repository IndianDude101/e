package Laksh;

import Laksh.LinkedList.LinkedList;
import Laksh.LinkedList.Node;

public class Main {

    public static void main(String[] args) {
        LinkedList l = new LinkedList(2);

        l.add(new Node(4));
        l.add(new Node(6));
        l.add(new Node(8));
    }
}
