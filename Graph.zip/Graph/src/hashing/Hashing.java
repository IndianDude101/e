/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashing;


import java.util.Arrays;

/**
 *
 * @author Laksh
 */
public class Hashing <K, V>{
    protected final Pairs<K, V>[] arr;
    private final int maxSize;
    private int length;



    public static void main(String[] args) {
        Adja

    }

    public Hashing(int maxSize){
        this.maxSize = maxSize;
        arr = new Pairs[maxSize];
        length = 0;
    }
    
    public String[] asArray() {
        String[] elements = new String[maxSize];
        for (int i = 0; i < maxSize; i++){
            if (arr[i] != null){
                elements[i] = arr[i].getValue().toString();
            }else{
                elements[i] = null;
            }
        }
        return elements;
    }    


    public void add(K Key, V Value) {

        if (length == maxSize) {
            throw new UnsupportedOperationException();
        }
        if (contains(Key)){
            throw new IllegalArgumentException();
        }
        Pairs pair = new Pairs(Key, Value);


        arr[getHash(Key, null)] = pair;

        length++;
    }


    public V item(K Key) {
        return arr[getHash(Key, String.valueOf(Key))].getValue();
    }


    public void delete(K Key) {
        arr[getHash(Key, String.valueOf(Key))] = null;

        length--;
    }


    public boolean contains(K Key) {
        try{
            arr[getHash(Key, String.valueOf(Key))].getKey();
            return true;
        }catch (IllegalArgumentException e){
            return false;
        }
    }


    public int length() {
        return length;
    }


    public boolean isEmpty() {
        return length == 0;
    }

    private int getHash(K key, String CollisionCheck){
        int hash = -1;
        int keyInt = key.hashCode();

        for (int i = keyInt % maxSize; i < (keyInt % maxSize) + maxSize; i++){
            int x = i % maxSize;

            if (arr[x] == null){
                 if (CollisionCheck == null){
                     hash = x;
                     break;
                 }
            }else if (CollisionCheck != null){
                if (CollisionCheck.equals(String.valueOf(arr[x].getKey()))){
                    hash = x;
                    break;
                }
            }
        }
        if (hash == -1){
            throw new IllegalArgumentException();
        }
        return hash;
    }


    public String toString() {
        StringBuilder s = new StringBuilder("{");
        for (int i = 0; i < maxSize; i++){
            Pairs x = arr[i];
            if (x == null){
                s.append("null:null" + (i != maxSize ? ", " : ""));
                continue;
            }
            s.append(x.getKey() + ":" + x.getValue() + (i != maxSize - 1 ? ", " : ""));
        }
        s.append("}");
        return s.toString();
    }
}
