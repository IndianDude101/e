package Graph;public class AdjacencyList {
}
