import hashing.Hashing;
import hashing.Pairs;

import java.util.HashMap;

public class AdjacencyList<K, V> extends Hashing {
    public AdjacencyList(int maxSize) {
        super(maxSize);
    }

    public void add(String Key, Hashing Value) { // TODO think about getting inputs
        super.add(totalASCII(Key.toCharArray()), Value.toString());
    }

    private int totalASCII(char[] str){
        int total = 0;
        for (char c : str){
            total += (int) c;
        }
        return total;
    }


}
