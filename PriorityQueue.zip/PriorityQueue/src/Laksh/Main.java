package Laksh;

import Laksh.Queue.Node;
import Laksh.Queue.Queue;

public class Main {

    public static void main(String[] args) {
        Queue q = new Queue(6);
       
    }
}
