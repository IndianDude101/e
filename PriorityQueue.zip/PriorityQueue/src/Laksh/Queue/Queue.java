package Laksh.Queue;

import java.util.ArrayList;

public class Queue {
    private final int maxSize;
    private int head, tail;
    private final ArrayList<Node> queue;

    public Queue(int maxSize){
        this.maxSize = maxSize;
        queue = new ArrayList<>(maxSize);
        head = 0;
        tail = -1;
    }

    public boolean isEmpty(){
        return queue.isEmpty();
    }

    public boolean isFull() {
        return queue.size() == maxSize;
    }

    public void add(Node n){
        if (isFull()){
            throw new IndexOutOfBoundsException("Queue is full");
        }
        tail++;

        for (int i = 0; i <= tail; i++){
            if (i == tail){
                if(!isEmpty()){
                    queue.get(i-1).setNext(n);
                }
                queue.add(n);
                break;
            }
            if(queue.get(i).getValue() > n.getValue()){
                queue.get(i).setNext(n);
                queue.add(i, n);
                n.setNext(queue.get(i + 1));
                break;
            }

        }
    }

    public Node remove(){
        return queue.remove(0);
    }

    @Override
    public String toString() {
        StringBuilder x = new StringBuilder("[");
        for (Node n : queue){
            if (n == null){
                continue;
            }
            x.append(n.getValue()).append(n.getNext() == null ? "" : ",");
        }
        x.append("]");
        return x.toString();
    }

    public int getHead() {
        return head;
    }

    public void setHead(int head) {
        this.head = head;
    }

    public int getTail() {
        return tail;
    }

    public void setTail(int tail) {
        this.tail = tail;
    }
}
