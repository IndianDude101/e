package Laksh;

import Laksh.Tree.Renderer;
import Laksh.Tree.Tree;
import com.sun.org.apache.regexp.internal.RE;

public class Main {

    public static void main(String[] args) {
        Tree<String> t = new Tree<>();
        Renderer r = new Renderer(0, t);

        t.add("Jim");
        t.add("Alice");
        t.add("Belinda");
        t.add("Kevin");


        r.printTree();

    }

}
