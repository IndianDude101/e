package Laksh.Tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Renderer extends Tree{

    private int padding;
    private Tree tree;

    public Renderer(int padding, Tree tree){
        this.padding = padding;
        this.tree = tree;
    }

    private String genSpace(int amount){
        return new String(new char[amount]).replace("\0", " ");
    }

    public void printTree(){
        Queue<Node> queue = new LinkedList<Node>();
        Node[][] n = new Node[getDepth(tree.getRoot())][];

        queue.add(tree.getRoot());
        int count = 0;
        for (int i = 0; i < getSize(); i++){
            n[i][count]
        }

        while (!queue.isEmpty()) {
            Node temp = queue.poll();
            System.out.print(temp.getValue() + " ");

            if (temp.getLeft() != null) {
                queue.add(temp.getLeft());
            }

            if (temp.getRight() != null) {
                queue.add(temp.getRight());
            }
        }
    }
}
