package Laksh.Tree;

public class Tree<T extends Comparable> {

    private Node<T> root;
    private int size;


    public Tree(Node<T> root){
        this.root = root;
        size = 1;
    }

    public Tree(){
        this.root = null;
        size = 0;
    }

    public void add(T value){
        root = addRec(root, value);
    }

    private Node<T> addRec(Node<T> current, T value){
        if (current == null){
            current = new Node<T>(value);
            size++;
        }
        else if (value.compareTo(current.getValue()) > 0){
            current.setRight(addRec(current.getRight(), value));

        } else if (value.compareTo(current.getValue()) < 0){
            current.setLeft(addRec(current.getLeft(), value));
        }

        return current;
    }

    public void inOrder(){
        inOrderRec(root);
    }

    private Node<T> inOrderRec(Node<T> current){
        if (current != null){
            inOrderRec(current.getLeft());
            System.out.println(current.getValue());
            inOrderRec(current.getRight());
        }
        return current;
    }

    public void preOrder(){
        preOrderRec(root);
    }

    private Node<T> preOrderRec(Node<T> current){
        if (current != null){
            System.out.println(current.getValue());
            inOrderRec(current.getLeft());
            inOrderRec(current.getRight());
        }
        return current;
    }

    public void postOrder(){
        postOrderRec(root);
    }

    private Node<T> postOrderRec(Node<T> current){
        if (current != null){
            inOrderRec(current.getLeft());
            inOrderRec(current.getRight());
            System.out.println(current.getValue());
        }
        return current;
    }

    public int getSize() {
        return size;
    }

    public int getDepth(Node<T> current){
        if (current == null){
            return 0;
        }else{
            int left = getDepth(current.getLeft());
            int right = getDepth(current.getRight());
            return 1 + Math.max(left, right);
        }
    }

    public Node<T> getRoot() {
        return root;
    }

}
