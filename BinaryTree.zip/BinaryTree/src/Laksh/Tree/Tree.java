package Laksh.Tree;

public class Tree<T> {

    private final Node<T> root;
    private int size, depth;


    public Tree(Node<T> root){
        this.root = root;
        size = 0;
        depth = 1;
    }

    public void add(Node<T> node){
        if ()

    }

    public Node<T> getRoot() {
        return root;
    }

}
